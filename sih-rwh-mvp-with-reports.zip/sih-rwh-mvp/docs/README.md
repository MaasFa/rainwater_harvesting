# SIH 2025 – RWH MVP Docs

- `flowchart.png`: high-level app flow for MVP.
- Use the root README below for step-by-step run instructions.
