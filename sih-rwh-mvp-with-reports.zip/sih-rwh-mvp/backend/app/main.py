from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .routers import reports
from .core import rainfall

from .routers import auth, sites, assessments
from .core.database import Base, engine
from sqlalchemy import func

Base.metadata.create_all(bind=engine)

app = FastAPI(title="RWH Assessment API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(sites.router, prefix="/sites", tags=["sites"])
app.include_router(assessments.router, prefix="/assessments", tags=["assessments"])
app.include_router(reports.router, prefix="", tags=["reports"])
app.mount('/reports', StaticFiles(directory='app/reports'), name='reports')


@app.get('/metrics')
def metrics(db=Depends(get_db)):
    # Return aggregate metrics: total assessments, total harvest (L/yr), feasible count
    session = next(db)
    from .models.models import Assessment
    total = session.query(Assessment).count()
    total_harvest = session.query(Assessment).with_entities(func.sum(Assessment.harvest_potential_lpy)).scalar() or 0
    feasible = session.query(Assessment).filter(Assessment.recharge_feasible == True).count()
    return {'total_assessments': total, 'total_harvest_lpy': float(total_harvest), 'feasible_count': feasible}

@app.get("/health")
def health():
    return {"status": "ok"}
